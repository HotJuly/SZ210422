export default {
  mpHost: "http://localhost:3000"
}